# Lib_Mgt_02
Simple library management java application

Git clone and open in android studio to work on it
It will automatically connect to firebase (I beleive)

### Users: (email/password)
* `user@example.com`/user
* `sur@example.com`/sur
* `sam@example.com`/sam
