package com.example.lib_mgt_02;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

public class Book implements Serializable {
    private String id;
    private String author;
    private int count;
    private String title;
    private List<String> genre;
    private List<String> lent;
    private List<String> reserved;

    public Book() {

    }

    public Book(String id, String author, int count, String title, List<String> genre, List<String> lent, List<String> reserved) {
        this.id = id;
        this.author = author;
        this.count = count;
        this.title = title;
        this.genre = genre;
        this.lent = lent;
        this.reserved = reserved;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getGenre() {
        return genre;
    }

    public void setGenre(List<String> genre) {
        this.genre = genre;
    }

    public List<String> getLent() {
        return lent;
    }

    public void setLent(List<String> lent) {
        this.lent = lent;
    }

    public List<String> getReserved() {
        return reserved;
    }

    public void setReserved(List<String> reserved) {
        this.reserved = reserved;
    }
}

