package com.example.lib_mgt_02;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.GridView;

import java.util.List;

public class BooksActivity extends AppCompatActivity {
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar!=null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        List<Book> bookList = (List<Book>) intent.getSerializableExtra("bookList");
        userId = intent.getStringExtra("userid");
//        if(!bookList.isEmpty()) {
//            Toast.makeText(this, bookList.get(0).getTitle(),Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(this, "hellooo",Toast.LENGTH_SHORT).show();
//        }

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) GridView gridView = findViewById(R.id.bookGrid);
        BookAdapter adapter = new BookAdapter(this, bookList, userId);
        gridView.setAdapter(adapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}