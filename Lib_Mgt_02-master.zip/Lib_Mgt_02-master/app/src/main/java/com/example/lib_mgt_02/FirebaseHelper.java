package com.example.lib_mgt_02;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class FirebaseHelper {
    private FirebaseFirestore db;
//    private UserViewModel userViewModel;

    public FirebaseHelper() {
        db = FirebaseFirestore.getInstance();
    }

    public void authenticateUser(String email, String password, View view) {
        db.collection("users")
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        if(queryDocumentSnapshots.isEmpty()) {
                            Toast.makeText(view.getContext(),"Invalid email",Toast.LENGTH_SHORT).show();
                        }
                        else {
                            DocumentSnapshot documentSnapshot = queryDocumentSnapshots.getDocuments().get(0);
                            if(password.equals(documentSnapshot.getString("password"))) {

                                Activity activity = (Activity) view.getContext();

//                                userViewModel = new ViewModelProvider((ViewModelStoreOwner) activity).get(UserViewModel.class);
//                                userViewModel.setUser(documentSnapshot.toObject(User.class));

//                                User user = documentSnapshot.toObject(User.class);

                                SharedPreferences preferences = activity.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putString("email",email);
                                editor.putString("password", password);
                                editor.apply();

                                Intent intent = new Intent(view.getContext(), HomeActivity.class);
//                                intent.putExtra("user",user);
                                activity.startActivity(intent);
                                activity.finish();
                            }
                            else {
                                Toast.makeText(view.getContext(),"Invalid password",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(view.getContext(), "Authentication Failed",Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void getUserDetails(String email, final OngetUserDetailsCallback callback) {
        db.collection("users")
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        DocumentSnapshot documentSnapshot = queryDocumentSnapshots.getDocuments().get(0);
                        User user = documentSnapshot.toObject(User.class);
                        callback.ongetUserDetailsReceived(user);
                }});
    }

    public interface OngetUserDetailsCallback {
        void ongetUserDetailsReceived(User user);
    }

    public void searchedBooks(String title, String author, String genre, String userid, View view) {
        Query baseQuery = db.collection("books");
        if (!title.isEmpty()) {
            baseQuery = baseQuery.whereEqualTo("title", title);
        }
        if (!author.isEmpty()) {
            baseQuery = baseQuery.whereEqualTo("author", author);
        }
        if (!genre.isEmpty()) {
            baseQuery = baseQuery.whereArrayContains("genre", genre);
        }
        baseQuery.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Book> bookList = new ArrayList<>();
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            bookList.add(documentSnapshot.toObject(Book.class));
                        }
                        Activity activity = (Activity) view.getContext();
                        Intent intent = new Intent(view.getContext(), BooksActivity.class);
                        intent.putExtra("bookList", (Serializable) bookList);
                        intent.putExtra("userid", userid);
                        activity.startActivity(intent);
                    }
                });
    }

    public void searchedUserBooks(List<String> bookIdList, View view, String userid) {
        List<Book> bookList = new ArrayList<>();
        if(bookIdList.size() == 0) {
            Activity activity = (Activity) view.getContext();
            Intent intent = new Intent(view.getContext(), BooksActivity.class);
            intent.putExtra("bookList", (Serializable) bookList);
            intent.putExtra("userid", userid);
            activity.startActivity(intent);
        } else {
            AtomicInteger successCounter = new AtomicInteger(0);
            CollectionReference booksRef = db.collection("books");
            bookIdList.forEach(id -> {
                booksRef.document(id)
                        .get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                bookList.add(documentSnapshot.toObject(Book.class));
                                successCounter.getAndIncrement();
                                if (successCounter.get() == bookIdList.size()) {
                                    Activity activity = (Activity) view.getContext();
                                    Intent intent = new Intent(view.getContext(), BooksActivity.class);
                                    intent.putExtra("bookList", (Serializable) bookList);
                                    intent.putExtra("userid", userid);
                                    activity.startActivity(intent);
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(view.getContext(), "Reserved books Failed", Toast.LENGTH_SHORT).show();
                            }
                        });
            });
        }
    }

    public void getBook(String userId, String bookId) {
        db.collection("users").document(userId)
                .update("lent", FieldValue.arrayUnion(bookId));
        db.collection("books").document(bookId)
                .update("lent", FieldValue.arrayUnion(userId));
    }

    public void reserveBook(String userId, String bookId) {
        db.collection("users").document(userId)
                .update("reserved", FieldValue.arrayUnion(bookId));
        db.collection("books").document(bookId)
                .update("reserved", FieldValue.arrayUnion(userId));
    }

    public void returnBook(String userId, String bookId) {
        db.collection("users").document(userId)
                .update("lent", FieldValue.arrayRemove(bookId))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        db.collection("books").document(bookId)
                                .update("lent", FieldValue.arrayRemove(userId))
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        db.collection("books").document(bookId)
                                                .get()
                                                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                                    @Override
                                                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                                                        Book book = documentSnapshot.toObject(Book.class);
                                                        if(!book.getReserved().isEmpty()) {
                                                            getBook(book.getReserved().get(0), bookId);
                                                            cancelBookReserve(book.getReserved().get(0), bookId);
                                                        }
                                                    }
                                                });
                                    }
                                });
                    }
                });

    }

    public void cancelBookReserve(String userId, String bookId) {
        db.collection("users").document(userId)
                .update("reserved", FieldValue.arrayRemove(bookId));
        db.collection("books").document(bookId)
                .update("reserved", FieldValue.arrayRemove(userId));
    }

}
