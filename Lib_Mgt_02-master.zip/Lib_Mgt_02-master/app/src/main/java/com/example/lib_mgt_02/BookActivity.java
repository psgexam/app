package com.example.lib_mgt_02;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class BookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar!=null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        Book book = (Book) intent.getSerializableExtra("book");

        TextView title = findViewById(R.id.bookDetailsTitle);
        TextView author = findViewById(R.id.bookDetailsAuthor);
        TextView genre = findViewById(R.id.bookDetailsGenre);
        title.setText(book.getTitle());
        author.setText(book.getAuthor());
        StringBuilder genreString = new StringBuilder("");
        for (String genreName :
                book.getGenre()) {
            genreString.append('\n').append(genreName);
        }
        genre.setText(genreString);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}